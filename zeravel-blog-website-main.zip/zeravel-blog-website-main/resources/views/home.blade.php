@extends('layouts.main')

@section('container')
    <h1 class="ms-3">Home Page</h1>
@endsection